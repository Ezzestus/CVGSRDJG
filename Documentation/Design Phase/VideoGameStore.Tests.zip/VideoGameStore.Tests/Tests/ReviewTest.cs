﻿/* File Name: 
 * ReviewTest.cs
 * 
 * File Description:
 * Test class for the generated model class called 'review'
 * 
 * Revision History:
 * Greg Shalay, 10/27/2016 - Created Code
 */
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;

namespace VideoGameStore.Tests
{
    [TestClass]
    public class ReviewTest
    {
        [TestMethod]
        public void ReviewConstructorTest()
        {
            review review = new review();

            Assert.IsNotNull(review);
        }

        [TestMethod]
        public void ReviewIDTest()
        {
            review review = new review();
            int expected = 51;
            int actual;

            review.review_id = expected;
            actual = review.review_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void ReviewCustomerIDTest()
        {
            review review = new review();
            int expected = 51;
            int actual;

            review.customer_id = expected;
            actual = review.customer_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void ReviewGameIDTest()
        {
            review review = new review();
            int expected = 28;
            int actual;

            review.game_id = expected;
            actual = review.game_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void ReviewDateTest()
        {
            review review = new review();
            DateTime expected = new DateTime(2003, 2, 1);
            DateTime actual = new DateTime();

            review.review_date = expected;
            actual = review.review_date;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void ReviewIsApprovedTest()
        {
            review review = new review();
            bool expected = true;
            bool actual;

            review.is_approved = expected;
            actual = review.is_approved;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void ReviewIsDeletedTest()
        {
            review review = new review();
            bool expected = true;
            bool actual;

            review.is_deleted = expected;
            actual = review.is_deleted;

            Assert.AreEqual(expected, actual);
        }

    }
}
