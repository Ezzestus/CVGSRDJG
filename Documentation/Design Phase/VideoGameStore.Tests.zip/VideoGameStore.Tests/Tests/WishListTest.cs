﻿/* File Name: 
 * WishListTest.cs
 *
 * File Description:
 * Test class for the generated model class named 'wish_list' 
 * 
 * Revision History:
 * Greg Shalay, 10/27/2016 - Created Code
 */
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;

namespace VideoGameStore.Tests
{
    [TestClass]
    public class WishListTest
    {
        [TestMethod]
        public void WishListConstructorTest()
        {
            wish_list wishList = new wish_list();

            Assert.IsNotNull(wishList);
        }

        [TestMethod]
        public void WishListIDTest()
        {
            wish_list wishList = new wish_list();
            int expected = 23;
            int actual;

            wishList.wish_list_id = expected;
            actual = wishList.wish_list_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void WishListCustomerIDTest()
        {
            wish_list wishList = new wish_list();
            int expected = 23;
            int actual;

            wishList.customer_id = expected;
            actual = wishList.customer_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void WishListGameIDTest()
        {
            wish_list wishList = new wish_list();
            int expected = 23;
            int actual;

            wishList.game_id = expected;
            actual = wishList.game_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void WishListDateAddedTest()
        {
            wish_list wishList = new wish_list();
            DateTime expected = new DateTime(1995, 12, 23);
            DateTime actual = new DateTime();

            wishList.date_added = expected;
            actual = wishList.date_added;

            Assert.AreEqual(expected, actual);
        }

    }
}
