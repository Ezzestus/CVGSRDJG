﻿/* File Name:
 * CustomerTest.cs
 * 
 * File Description:
 * Test class for the generated model class named 'customer' 
 *
 * Revision History:
 * Greg Shalay, 10/27/2016 - Created Code 
 */
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;
namespace VideoGameStore.Tests
{
    [TestClass]
    public class CustomerTest
    {
        [TestMethod]
        public void CustomerConstructorTest()
        {
            customer customer = new customer();

            Assert.IsNotNull(customer);
        }

        [TestMethod]
        public void CustomerIDTest()
        {
            customer customer = new customer();
            int expected = 1;
            int actual;

            customer.customer_id = expected;
            actual = customer.customer_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerUsernameTest()
        {
            customer customer = new customer();
            string expected = "CaptainWonderbar";
            string actual;

            customer.username = expected;
            actual = customer.username;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerEmailTest()
        {
            customer customer = new customer();
            string expected = "CaptainWunderbar@wunderbar.com";
            string actual;

            customer.email = expected;
            actual = customer.email;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerPasswordTest()
        {
            customer customer = new customer();
            string expected = "wunderbar23432";
            string actual;

            customer.customer_password = expected;
            actual = customer.customer_password;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerLoginFailuresTest()
        {
            customer customer = new customer();
            int expected = 12;
            int actual;

            customer.login_failures = expected;
            actual = customer.login_failures;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerFirstNameTest()
        {
            customer customer = new customer();
            string expected = "Gerrard";
            string actual;

            customer.first_name = expected;
            actual = customer.first_name;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerLastNameTest()
        {
            customer customer = new customer();
            string expected = "Wunter";
            string actual;

            customer.last_name = expected;
            actual = customer.last_name;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerPhoneNumberTest()
        {
            customer customer = new customer();
            string expected = "(519) 555-5555";
            string actual;

            customer.phone = expected;
            actual = customer.phone;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerGenderTest()
        {
            customer customer = new customer();
            string expected = "Male";
            string actual;

            customer.gender = expected;
            actual = customer.gender;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerBirthDateTest()
        {
            customer customer = new customer();
            DateTime expected = new DateTime(2005, 3, 7);
            DateTime actual = new DateTime();

            customer.birthdate = expected;
            actual = customer.birthdate;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerDateJoinedTest()
        {
            customer customer = new customer();
            DateTime expected = new DateTime(2010, 8, 9);
            DateTime actual = new DateTime();

            customer.date_joined = expected;
            actual = customer.date_joined;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerIsMemberTest()
        {
            customer customer = new customer();
            bool expected = true;
            bool actual;

            customer.is_member = expected;
            actual = customer.is_member;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerIsInactiveTest()
        {
            customer customer = new customer();
            bool expected = true;
            bool actual;

            customer.is_inactive = expected;
            actual = customer.is_inactive;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerIsLockedOutTest()
        {
            customer customer = new customer();
            bool expected = true;
            bool actual;

            customer.is_locked_out = expected;
            actual = customer.is_locked_out;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerIsOnEmailListTest()
        {
            customer customer = new customer();
            bool expected = true;
            bool actual;

            customer.is_on_email_list = expected;
            actual = customer.is_on_email_list;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerFavoritePlatformTest()
        {
            customer customer = new customer();
            string expected = "PC";
            string actual;

            customer.favorite_platform = expected;
            actual = customer.favorite_platform;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerFavoriteCategoryTest()
        {
            customer customer = new customer();
            string expected = "Horror";
            string actual;

            customer.favorite_category = expected;
            actual = customer.favorite_category;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerNotesTest()
        {
            customer customer = new customer();
            string expected = "This is a note.";
            string actual;

            customer.notes = expected;
            actual = customer.notes;

            Assert.AreEqual(expected, actual);
        }

    }
}
