﻿/* File Name: 
 * Greg Shalay
 * 
 * File Description:
 * Test class for the generated model class named 'province' 
 *
 * Revision History:
 * Greg Shalay, 10/27/2016 - Created Code
 */
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;
namespace VideoGameStore.Tests
{
    [TestClass]
    public class ProvinceTest
    {
        [TestMethod]
        public void ProvinceConstructorTest()
        {
            province province = new province();

            Assert.IsNotNull(province);
        }

        [TestMethod]
        public void ProvinceIDTest()
        {
            province province = new province();
            int expected = 7;
            int actual;

            province.province_id = expected;
            actual = province.province_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void ProvinceCodeTest()
        {
            province province = new province();
            string expected = "ON";
            string actual;

            province.province_code = expected;
            actual = province.province_code;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void ProvinceNameTest()
        {
            province province = new province();
            string expected = "Ontario";
            string actual;

            province.province_name = expected;
            actual = province.province_name;

            Assert.AreEqual(expected, actual);
        }

    }
}
