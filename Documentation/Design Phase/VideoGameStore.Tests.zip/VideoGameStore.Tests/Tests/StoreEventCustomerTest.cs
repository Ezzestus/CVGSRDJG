﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;

namespace VideoGameStore.Tests
{
    [TestClass]
    public class StoreEventCustomerTest
    {
        [TestMethod]
        public void StoreEventCustomerConstructorTest()
        {
            store_event_customer sec = new store_event_customer();

            Assert.IsNotNull(sec);
        }

        [TestMethod]
        public void StoreEventIDTest()
        {
            store_event_customer sec = new store_event_customer();
            int expected = 12;
            int actual;

            sec.store_event_id = expected;
            actual = sec.store_event_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void StoreEventCustomerIDTest()
        {
            store_event_customer sec = new store_event_customer();
            int expected = 999;
            int actual;

            sec.store_event_customer_id = expected;
            actual = sec.store_event_customer_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerIDTest()
        {
            store_event_customer sec = new store_event_customer();
            int expected = 999;
            int actual;

            sec.customer_id = expected;
            actual = sec.customer_id;

            Assert.AreEqual(expected, actual);
        }
    }
}
