﻿/* File Name: EmployeeAddressTest.cs
 * 
 * File Description:
 * Test class for the generated model class 'employee_address'
 *
 * Revision History:
 * Greg Shalay, 10/27/2016 - Created Code 
 */
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;

namespace VideoGameStore.Tests
{
    [TestClass]
    public class EmployeeAddressTest
    {
        [TestMethod]
        public void EmployeeAddressConstructorTest()
        {
            employee_address empAddress = new employee_address();

            Assert.IsNotNull(empAddress);
        }

        [TestMethod]
        public void EmployeeAddressEmployeeIDTest()
        {
            employee_address empAddress = new employee_address();
            int expected = 34;
            int actual;

            empAddress.employee_id = expected;
            actual = empAddress.employee_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void EmployeeAddressAddressIDTest()
        {
            employee_address empAddress = new employee_address();
            int expected = 34;
            int actual;

            empAddress.address_id = expected;
            actual = empAddress.address_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void EmployeeAddressAddressNameTest()
        {
            employee_address empAddress = new employee_address();
            string expected = "765 Fake Avenue";
            string actual;

            empAddress.address_name = expected;
            actual = empAddress.address_name;

            Assert.AreEqual(expected, actual);
        }

    }
}
