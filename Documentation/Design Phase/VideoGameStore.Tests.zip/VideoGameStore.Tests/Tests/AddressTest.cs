﻿/* File Name: AddressTest.cs
 * 
 * File Description:
 * A test class for the address model class.
 * 
 * Revision History:
 * Greg Shalay, 10/27/2016 - Created Code
 */

using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;

namespace VideoGameStore.Tests
{
    [TestClass]
    public class AddressTest
    {

        [TestMethod]
        public void AddressConstructorTest()
        {
            address address = new address();

            Assert.IsNotNull(address);
        }

        [TestMethod]
        public void AddressIDTest()
        {
            address address = new address();
            int expected = 1212;
            int actual;

            address.address_id = expected;
            actual = address.address_id;


            Assert.AreEqual(actual, expected);
        }

        [TestMethod]
        public void StreetAddressTest()
        {
            address address = new address();
            string expected = "123 Fakeville North";
            string actual;

            address.street_address = expected;
            actual = address.street_address;

            Assert.AreEqual(actual, expected);
        }

        [TestMethod]
        public void AddressCityTest()
        {
            address address = new address();
            string expected = "The Most Awesome City!";
            string actual;

            address.city = expected;
            actual = address.city;

            Assert.AreEqual(actual, expected);
        }

        [TestMethod]
        public void AddressProvinceIDTest()
        {
            address address = new address();
            int expected = 23;
            int actual;

            address.province_id = expected;
            actual = address.province_id;

            Assert.AreEqual(address.province_id, expected);
        }


        [TestMethod]
        public void AddressPostalCodeTest()
        {
            address address = new address();
            string expected = "A1A 1A1";
            string actual;

            address.postal_code = expected;
            actual = address.postal_code;

            Assert.AreEqual(actual, expected);
        }
    }
}
