﻿/* File Name: 
 * PublisherTest.cs
 * 
 * File Description:
 * Test class for the generated model class named 'publisher'
 * 
 * Revision History:
 * Greg Shalay, 10/27/2016 - Created Code
 */
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models; 

namespace VideoGameStore.Tests
{
    [TestClass]
    public class PublisherTest
    {
        [TestMethod]
        public void PublisherConstructorTest()
        {
            publisher publisher = new publisher();

            Assert.IsNotNull(publisher);
        }

        [TestMethod]
        public void PublisherNameTest()
        {
            publisher publisher = new publisher();
            string expected = "The Real Publisher";
            string actual;

            publisher.publisher_name = expected;
            actual = publisher.publisher_name;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void PublisherContactNameTest()
        {
            publisher publisher = new publisher();
            string expected = "Jill Dennings";
            string actual;

            publisher.contact_name = expected;
            actual = publisher.contact_name;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void PublisherContactPhoneTest()
        {
            publisher publisher = new publisher();
            string expected = "(555) 555-5555";
            string actual;

            publisher.contact_phone = expected;
            actual = publisher.contact_phone;

            Assert.AreEqual(expected, actual);
        }


        [TestMethod]
        public void PublisherContactEmailTest()
        {
            publisher publisher = new publisher();
            string expected = "publisher@publish.ca";
            string actual;

            publisher.contact_email = expected;
            actual = publisher.contact_email;

            Assert.AreEqual(expected, actual);
        }

    }
}
