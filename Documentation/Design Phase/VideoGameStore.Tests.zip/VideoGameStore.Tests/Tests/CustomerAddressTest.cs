﻿/* File Name:
 * CustomerAddressTest.cs
 * 
 * File Description: 
 * Test class for the generated model class named 'customer_address'
 *
 * Revision History:
 * Greg Shalay, 10/27/2016 - Created Code 
 */

using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;

namespace VideoGameStore.Tests
{
    [TestClass]
    public class CustomerAddressTest
    {
        [TestMethod]
        public void CustomerAddressConstructorTest()
        {
            customer_address customerAddress = new customer_address();

            Assert.IsNotNull(customerAddress);
        }

        [TestMethod]
        public void CustomerIDTest()
        {
            customer_address customerAddress = new customer_address();
            int expected = 10;
            int actual;

            customerAddress.customer_id = expected;
            actual = customerAddress.customer_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void AddressIDTest()
        {
            customer_address customerAddress = new customer_address();
            int expected = 10;
            int actual;

            customerAddress.address_id = expected;
            actual = customerAddress.address_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void AddressNameTest()
        {
            customer_address customerAddress = new customer_address();
            string expected = "23 Wilson Ave";
            string actual;

            customerAddress.address_name = expected;
            actual = customerAddress.address_name;

            Assert.AreEqual(expected, actual);
        }
    }
}
