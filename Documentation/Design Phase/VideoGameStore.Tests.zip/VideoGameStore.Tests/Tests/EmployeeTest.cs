﻿/* File Name: EmployeeTest.cs
 *
 * File Description:
 * Class that tests all fields in the generated model class 'employee'
 * 
 * Revision History:
 * Greg Shalay, 10/27/2016 - Created Code
 */
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;

namespace VideoGameStore.Tests
{
    [TestClass]
    public class EmployeeTest
    {
        [TestMethod]
        public void EmployeeConstructorTest()
        {
            employee employee = new employee();

            Assert.IsNotNull(employee);
        }

        [TestMethod]
        public void EmployeeIDTest()
        {
            employee employee = new employee();
            int expected = 90;
            int actual;

            employee.employee_id = expected;
            actual = employee.employee_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void EmployeePasswordTest()
        {
            employee employee = new employee();
            string expected = "1234";
            string actual;

            employee.employee_password = expected;
            actual = employee.employee_password;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void EmployeeLoginFailuresTest()
        {
            employee employee = new employee();
            int expected = 4;
            int actual;

            employee.login_failures = expected;
            actual = employee.login_failures;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void EmployeeFirstNameTest()
        {
            employee employee = new employee();
            string expected = "Winston";
            string actual;

            employee.first_name = expected;
            actual = employee.first_name;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void EmployeeLastNameTest()
        {
            employee employee = new employee();
            string expected = "Ping";
            string actual;

            employee.last_name = expected;
            actual = employee.last_name;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void EmployeePhoneNumberTest()
        {
            employee employee = new employee();
            string expected = "(519) 111-1212";
            string actual;

            employee.phone = expected;
            actual = employee.phone;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void EmployeeEmailTest()
        {
            employee employee = new employee();
            string expected = "greg_shalay@outlook.com";
            string actual;

            employee.email = expected;
            actual = employee.email;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void EmployeeGenderTest()
        {
            employee employee = new employee();
            string expected = "Female";
            string actual;

            employee.gender = expected;
            actual = employee.gender;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void EmployeeBirthDateTest()
        {
            employee employee = new employee();
            DateTime expected = new DateTime(2015, 1, 12);
            DateTime actual = new DateTime();

            employee.birthdate = expected;
            actual = employee.birthdate;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void EmployeeDateHiredTest()
        {
            employee employee = new employee();
            DateTime expected = new DateTime(1978, 10, 28);
            DateTime actual = new DateTime();

            employee.birthdate = expected;
            actual = employee.birthdate;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void EmployeeIsAdminTest()
        {
            employee employee = new employee();
            bool expected = false;
            bool actual;

            employee.is_admin = expected;
            actual = employee.is_admin;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void EmployeeIsInactiveTest()
        {
            employee employee = new employee();
            bool expected = true;
            bool actual;

            employee.is_inactive = expected;
            actual = employee.is_inactive;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void EmployeeIsLockedOutTest()
        {
            employee employee = new employee();
            bool expected = true;
            bool actual;

            employee.is_locked_out = expected;
            actual = employee.is_locked_out;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void EmployeeNotesTest()
        {
            employee employee = new employee();
            string expected = "This note is a very short one.";
            string actual;

            employee.notes = expected;
            actual = employee.notes;

            Assert.AreEqual(expected, actual);
        }


    }
}
