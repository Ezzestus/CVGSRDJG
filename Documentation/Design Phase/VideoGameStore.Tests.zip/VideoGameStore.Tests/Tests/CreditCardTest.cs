﻿/* File Name:
 * CreditCardTest.cs
 * 
 * File Description: 
 * Test class for the generated model class named 'credit_card' 
 * 
 * Revision History:
 * Greg Shalay, 10/27/2016 - Created Code
 */

using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;

namespace VideoGameStore.Tests
{
    [TestClass]
    public class CreditCardTest
    {
        [TestMethod]
        public void CreditCardConstructorTest()
        {
            credit_card creditCard = new credit_card();

            Assert.IsNotNull(creditCard);
        }

        [TestMethod]
        public void CreditCardIDTest()
        {
            credit_card creditCard = new credit_card();
            int expected = 9;
            int actual;

            creditCard.credit_card_id = expected;
            actual = creditCard.credit_card_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CreditCardNumberTest()
        {
            credit_card creditCard = new credit_card();
            long expected = 9002332232323232;
            long actual;

            creditCard.card_number = expected;
            actual = creditCard.card_number;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CreditCardExpiryDateTest()
        {
            credit_card creditCard = new credit_card();
            DateTime expected = new DateTime(2020, 1, 3); 
            DateTime actual = new DateTime();

            creditCard.expiry_date = expected;
            actual = creditCard.expiry_date;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CreditCardIsExpiredTest()
        {
            credit_card creditCard = new credit_card();
            bool expected = false;
            bool actual;

            creditCard.is_expired = expected;
            actual = creditCard.is_expired;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CreditCardIsFlaggedTest()
        {
            credit_card creditCard = new credit_card();
            bool expected = true;
            bool actual;

            creditCard.is_flagged = expected;
            actual = creditCard.is_flagged;

            Assert.AreEqual(expected, actual);
        }



    }
}
