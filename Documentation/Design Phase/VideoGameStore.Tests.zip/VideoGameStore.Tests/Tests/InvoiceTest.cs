﻿/* File Name: 
 * InvoiceTest.cs
 * 
 * File Description:
 * Test class for the generated model class 'invoice'
 *
 * Revision History:
 * Greg Shalay, 10/27/2016 - Created Code
 */

using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;

namespace VideoGameStore.Tests
{
    [TestClass]
    public class InvoiceTest
    {
        [TestMethod]
        public void InvoiceConstructorTest()
        {
            invoice invoice = new invoice();

            Assert.IsNotNull(invoice);
        }

        [TestMethod]
        public void InvoiceIDTest()
        {
            invoice invoice = new invoice();
            int expected = 45;
            int actual;

            invoice.invoice_id = expected;
            actual = invoice.invoice_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void InvoiceCustomerIDTest()
        {
            invoice invoice = new invoice();
            int expected = 81;
            int actual;

            invoice.customer_id = expected;
            actual = invoice.customer_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void InvoiceCreditCardIDTest()
        {
            invoice invoice = new invoice();
            int expected = 711;
            int actual;

            invoice.credit_card_id = expected;
            actual = invoice.credit_card_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void InvoiceDateTest()
        {
            invoice invoice = new invoice();
            DateTime expected = new DateTime(2007, 1, 1);
            DateTime actual = new DateTime();

            invoice.invoice_date = expected;
            actual = invoice.invoice_date;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void InvoiceShipDateTest()
        {
            invoice invoice = new invoice();
            DateTime expected = new DateTime(2009, 12, 3);
            DateTime? actual = new DateTime();

            invoice.ship_date = expected;
            actual = invoice.ship_date;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void IsInvoiceClosedTest()
        {
            invoice invoice = new invoice();
            bool expected = true;
            bool actual;

            invoice.is_invoice_closed = expected;
            actual = invoice.is_invoice_closed;

            Assert.AreEqual(expected, actual);
        }

    }
}
