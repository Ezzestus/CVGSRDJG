﻿/* File Name: CustomerGameTest.cs
 *
 * File Description: 
 * Test class for the generated model class 'customer_game' 
 * 
 * Revision History:
 * Greg Shalay, 10/27/2016 - Created Code
 */
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;

namespace VideoGameStore.Tests
{
    [TestClass]
    public class CustomerGameTest
    {
        [TestMethod]
        public void CustomerGameConstructorTest()
        {
            customer_game customerGame = new customer_game();

            Assert.IsNotNull(customerGame);
        }

        [TestMethod]
        public void CustomerGameIDTest()
        {
            customer_game customerGame = new customer_game();
            int expected = 464;
            int actual;

            customerGame.customer_game_id = expected;
            actual = customerGame.customer_game_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CustomerIDTest()
        {
            customer_game customerGame = new customer_game();
            int expected = 344;
            int actual;

            customerGame.customer_id = expected;
            actual = customerGame.customer_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GameIDTest()
        {
            customer_game customerGame = new customer_game();
            int expected = 43;
            int actual;

            customerGame.game_id = expected;
            actual = customerGame.game_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void DatePurchasedTest()
        {
            customer_game customerGame = new customer_game();
            DateTime expected = new DateTime(2000, 1, 1);
            DateTime actual = new DateTime();

            customerGame.date_purchased = expected;
            actual = customerGame.date_purchased;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void RatingTest()
        {
            customer_game customerGame = new customer_game();
            int expected = 43;
            int? actual;

            customerGame.rating = expected;
            actual = customerGame.rating;

            Assert.AreEqual(expected, actual);
        }

    }
}
