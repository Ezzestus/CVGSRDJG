﻿/* File Name: InvoiceAddressTest.cs
 *
 * File Description: 
 * Test class for the generated model class 'invoice_address' 
 * 
 * Revision History:
 * Greg Shalay, 10/27/2016 - Created Code
 */
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;

namespace VideoGameStore.Tests
{
    [TestClass]
    public class InvoiceAddressTest
    {
        [TestMethod]
        public void InvoiceAddressConstructorTest()
        {
            invoice_address invoiceAddress = new invoice_address();

            Assert.IsNotNull(invoiceAddress);
        }

        [TestMethod]
        public void InvoiceAddressIDTest()
        {
            invoice_address invoiceAddress = new invoice_address();
            int expected = 231;
            int actual;

            invoiceAddress.invoice_address_id = expected;
            actual = invoiceAddress.invoice_address_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void InvoiceIDTest()
        {
            invoice_address invoiceAddress = new invoice_address();
            int expected = 231;
            int actual;

            invoiceAddress.invoice_id = expected;
            actual = invoiceAddress.invoice_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void AddressIDTest()
        {
            invoice_address invoiceAddress = new invoice_address();
            int expected = 231;
            int actual;

            invoiceAddress.address_id = expected;
            actual = invoiceAddress.address_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void InvoiceAddressIsBillingAddressTest()
        {
            invoice_address invoiceAddress = new invoice_address();
            bool expected = false;
            bool actual;

            invoiceAddress.is_billing_address = expected;
            actual = invoiceAddress.is_billing_address;

            Assert.AreEqual(expected, actual);
        }
    }
}
