﻿/* File Name:
 * LineItemTest.cs
 * 
 * File Description:
 * Test class for the generated model class named 'line_item' 
 *
 * Revision History:
 * Greg Shalay, 10/27/2016 - Created Code
 */
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;

namespace VideoGameStore.Tests
{
    [TestClass]
    public class LineItemTest
    {
        [TestMethod]
        public void LineItemConstructorTest()
        {
            line_item lineItem = new line_item();

            Assert.IsNotNull(lineItem);
        }

        [TestMethod]
        public void LineItemIDTest()
        {
            line_item lineItem = new line_item();
            int expected = 67;
            int actual;

            lineItem.line_item_id = expected;
            actual = lineItem.line_item_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void LineItemInvoiceIDTest()
        {
            line_item lineItem = new line_item();
            int expected = 67;
            int actual;

            lineItem.invoice_id = expected;
            actual = lineItem.invoice_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void LineItemGamIDTest()
        {
            line_item lineItem = new line_item();
            int expected = 5;
            int actual;

            lineItem.game_id = expected;
            actual = lineItem.game_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void LineItemQuantityTest()
        {
            line_item lineItem = new line_item();
            int expected = 2;
            int actual;

            lineItem.quantity = expected;
            actual = lineItem.quantity;

            Assert.AreEqual(expected, actual);
        }

    }
}
