﻿/* File Name:
 * GameTest.cs
 * 
 * File Description:
 * Test class for the generated model partial class called 'game'
 * 
 * Revision History:
 * Greg Shalay, 10/27/2016 - Created Code
 */
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;

namespace VideoGameStore.Tests
{
    [TestClass]
    public class GameTest
    {
        [TestMethod]
        public void GameConstructorTest()
        {
            game game = new game();

            Assert.IsNotNull(game);
        }

        [TestMethod]
        public void GameIDTest()
        {
            game game = new game();
            int expected = 24;
            int actual;

            game.game_id = expected;
            actual = game.game_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GameNameTest()
        {
            game game = new game();
            string expected = "Overwatch";
            string actual;

            game.game_name = expected;
            actual = game.game_name;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GameDescriptionTest()
        {
            game game = new game();
            string expected = "Overwatch is awesome!!!";
            string actual;

            game.description = expected;
            actual = game.description;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GameCostTest()
        {
            game game = new game();
            decimal expected = 12;
            decimal actual;

            game.cost = expected;
            actual = game.cost;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GameListPriceTest()
        {
            game game = new game();
            decimal expected = 89;
            decimal actual;

            game.list_price = expected;
            actual = game.list_price;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GameOnHandTest()
        {
            game game = new game();
            int expected = 7;
            int actual;

            game.on_hand = expected;
            actual = game.on_hand;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GameDeveloperIDTest()
        {
            game game = new game();
            int expected = 34;
            int actual;

            game.developer_id = expected;
            actual = game.developer_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GamePublisherIDTest()
        {
            game game = new game();
            int expected = 7;
            int actual;

            game.publisher_id = expected;
            actual = game.publisher_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GameGenreIDTest()
        {
            game game = new game();
            int expected = 56;
            int actual;

            game.genre_id = expected;
            actual = game.genre_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GameReleaseDateTest()
        {
            game game = new game();
            DateTime expected = new DateTime(2004, 2, 3);
            DateTime actual = new DateTime();

            game.release_date = expected;
            actual = game.release_date;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GameIsOnSaleTest()
        {
            game game = new game();
            bool expected = false;
            bool actual;

            game.is_on_sale = expected;
            actual = game.is_on_sale;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GameIsDiscontinuedTest()
        {
            game game = new game();
            bool expected = true;
            bool actual;

            game.is_discontinued = expected;
            actual = game.is_discontinued;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GameIsDownloadableTest()
        {
            game game = new game();
            bool expected = false;
            bool actual;

            game.is_downloadable = expected;
            actual = game.is_downloadable;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GameIsPhysicalCopyTest()
        {
            game game = new game();
            bool expected = true;
            bool actual;

            game.is_discontinued = expected;
            actual = game.is_discontinued;

            Assert.AreEqual(expected, actual);
        }

    }
}
