﻿/* File Name:
 * FriendListTest.cs
 * 
 * File Description:
 * Test class for the generated model partial class named 'friend_list'
 * 
 * Revision History:
 * Greg Shalay, 10/27/2016 - Created Code 
 */
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;

namespace VideoGameStore.Tests
{
    [TestClass]
    public class FriendListTest
    {
        [TestMethod]
        public void FriendListConstructorTest()
        {
            friend_list friendList = new friend_list();

            Assert.IsNotNull(friendList);
        }

        [TestMethod]
        public void FriendListCustomerIDTest()
        {
            friend_list friendList = new friend_list();
            int expected = 34;
            int actual;

            friendList.customer_id = expected;
            actual = friendList.customer_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void FriendIDTest()
        {
            friend_list friendList = new friend_list();
            int expected = 34;
            int actual;

            friendList.friend_id = expected;
            actual = friendList.friend_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void FriendIsFamilyTest()
        {
            friend_list friendList = new friend_list();
            bool expected = true;
            bool actual;

            friendList.is_family = expected;
            actual = friendList.is_family;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void FriendDateAddedTest()
        {
            friend_list friendList = new friend_list();
            DateTime expected = new DateTime();
            DateTime actual = new DateTime();

            friendList.date_added = expected;
            actual = friendList.date_added;

            Assert.AreEqual(expected, actual);
        }

    }
}
