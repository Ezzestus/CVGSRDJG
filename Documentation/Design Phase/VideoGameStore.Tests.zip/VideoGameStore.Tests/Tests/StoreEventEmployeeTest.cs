﻿/* File Name: 
 * StoreEventEmployeeTest.cs
 * 
 * File Description:
 * Test class for the generated model class 'store_event_employee'
 * 
 * Revision History:
 * Greg Shalay, 10/27/2016 - Created Code
 */

using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;

namespace VideoGameStore.Tests
{
    [TestClass]
    public class StoreEventEmployeeTest
    {
        [TestMethod]
        public void StoreEventEmployeeConstructorTest()
        {
            store_event_employee sem = new store_event_employee();

            Assert.IsNotNull(sem);
        }

        [TestMethod]
        public void StoreEventEmployeeIDTest()
        {
            store_event_employee sem = new store_event_employee();
            int expected = 123;
            int actual;

            sem.store_event_employee_id = expected;
            actual = sem.store_event_employee_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void StoreEventIDTest()
        {
            store_event_employee sem = new store_event_employee();
            int expected = 123;
            int actual;

            sem.store_event_id = expected;
            actual = sem.store_event_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void EmployeeIDTest()
        {
            store_event_employee sem = new store_event_employee();
            int expected = 123;
            int actual;

            sem.employee_id = expected;
            actual = sem.employee_id;

            Assert.AreEqual(expected, actual);
        }
    }
}
