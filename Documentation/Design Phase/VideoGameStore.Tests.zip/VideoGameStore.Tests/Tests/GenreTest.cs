﻿/* File Name: 
 * Greg Shalay
 * 
 * File Description:
 * Test class for the generated model class called 'genre'
 *
 * Revision History:
 * Greg Shalay, 10/27/2016 - Created Code
 */
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;

namespace VideoGameStore.Tests
{
    [TestClass]
    public class GenreTest
    {
        [TestMethod]
        public void GenreConstructorTest()
        {
            genre genre = new genre();

            Assert.IsNotNull(genre);
        }

        [TestMethod]
        public void GenreIDTest()
        {
            genre genre = new genre();
            int expected = 564;
            int actual;

            genre.genre_id = expected;
            actual = genre.genre_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GenreNameTest()
        {
            genre genre = new genre();
            string expected = "Horror";
            string actual;

            genre.genre_name = expected;
            actual = genre.genre_name;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void GenreDescriptionTest()
        {
            genre genre = new genre();
            string expected = "Games that focus on suspense and plot developement to entise their audience.";
            string actual;

            genre.description = expected;
            actual = genre.description;

            Assert.AreEqual(expected, actual);
        }

    }
}
