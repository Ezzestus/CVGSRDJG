﻿/* File Name: 
 * DeveloperTest.cs
 * 
 * File Description:
 * Test class for the generated model class named 'developer'
 *
 */
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;

namespace VideoGameStore.Tests
{
    [TestClass]
    public class DeveloperTest
    {
        [TestMethod]
        public void DeveloperConstructorTest()
        {
            developer developer = new developer();

            Assert.IsNotNull(developer);
        }

        [TestMethod]
        public void DeveloperIDTest()
        {
            developer developer = new developer();
            int expected = 7;
            int actual;

            developer.developer_id = expected;
            actual = developer.developer_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void DeveloperNameTest()
        {
            developer developer = new developer();
            string expected = "Blizzard Entertainment";
            string actual;

            developer.developer_name = expected;
            actual = developer.developer_name;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void DeveloperContactNameTest()
        {
            developer developer = new developer();
            string expected = "Bill Ese";
            string actual;

            developer.contact_name = expected;
            actual = developer.contact_name;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void DeveloperContactPhoneNumberTest()
        {
            developer developer = new developer();
            string expected = "(519) 009 - 7765";
            string actual;

            developer.contact_phone = expected;
            actual = developer.contact_phone;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void DeveloperContactEmailTest()
        {
            developer developer = new developer();
            string expected = "Bill@Ese.com";
            string actual;

            developer.contact_email = expected;
            actual = developer.contact_email;

            Assert.AreEqual(expected, actual);
        }

    }
}
