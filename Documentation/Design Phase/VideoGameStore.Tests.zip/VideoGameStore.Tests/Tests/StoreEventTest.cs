﻿/* File Name: StoreEventTest.cs
 * 
 * File Description:
 * Test class for the model generated class 'store_event'
 *
 * Revision History: 
 * Greg Shalay 10/27/2016 - Created Code
 */
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VideoGameStore.Models;
namespace VideoGameStore.Tests
{
    [TestClass]
    public class StoreEventTest
    {
        [TestMethod]
        public void StoreEventConstructorTest()
        {
            store_event storeEvent = new store_event();

            Assert.IsNotNull(storeEvent);
        }

        [TestMethod]
        public void StoreEventIDTest()
        {
            store_event storeEvent = new store_event();
            int expected = 76;
            int actual;

            storeEvent.store_event_id = expected;
            actual = storeEvent.store_event_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void StoreEventNameTest()
        {
            store_event storeEvent = new store_event();
            string expected = "Friday Night Gaming";
            string actual;

            storeEvent.store_event_name = expected;
            actual = storeEvent.store_event_name;

            Assert.AreEqual(expected, actual);
        }


        [TestMethod]
        public void StoreEventDescriptionTest()
        {
            store_event storeEvent = new store_event();
            string expected = "Friday Night Gaming is awesome!";
            string actual;

            storeEvent.description = expected;
            actual = storeEvent.description;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void StoreEventAddressIDTest()
        {
            store_event storeEvent = new store_event();
            int expected = 98;
            int actual;

            storeEvent.address_id = expected;
            actual = storeEvent.address_id;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void StoreEventStartDateTest()
        {
            store_event storeEvent = new store_event();
            DateTime expected = new DateTime(1997, 12, 27);
            DateTime actual = new DateTime();

            storeEvent.start_date = expected;
            actual = storeEvent.start_date;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void StoreEventEndDateTest()
        {
            store_event storeEvent = new store_event();
            DateTime expected = new DateTime(1997, 12, 29);
            DateTime actual = new DateTime();

            storeEvent.end_date = expected;
            actual = storeEvent.end_date;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void StoreEventMaxRegistrantsTest()
        {
            store_event storeEvent = new store_event();
            int expected = 2000;
            int actual;

            storeEvent.max_registrants = expected;
            actual = storeEvent.max_registrants;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void StoreEventIsFullTest()
        {
            store_event storeEvent = new store_event();
            bool expected = false;
            bool actual;

            storeEvent.is_full = expected;
            actual = storeEvent.is_full;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void StoreEventIsMembersOnlyTest()
        {
            store_event storeEvent = new store_event();
            bool expected = true;
            bool actual;

            storeEvent.is_members_only = expected;
            actual = storeEvent.is_members_only;

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void StoreEventIsCancelledTest()
        {
            store_event storeEvent = new store_event();
            bool expected = false;
            bool actual;

            storeEvent.is_cancelled = expected;
            actual = storeEvent.is_cancelled;

            Assert.AreEqual(expected, actual);
        }

    }
}
